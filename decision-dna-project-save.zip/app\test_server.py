from fastapi import FastAPI
import uvicorn

app = FastAPI()

@app.get("/")
def read_root():
    return {"status": "ok", "message": "Baseline test successful"}

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8001)
