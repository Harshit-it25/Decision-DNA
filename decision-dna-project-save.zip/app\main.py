from fastapi import FastAPI, HTTPException, Request, Depends, BackgroundTasks, APIRouter
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field
from prometheus_fastapi_instrumentator import Instrumentator
import joblib
import pandas as pd
import numpy as np
import os
import sys
import json
from datetime import datetime, timedelta
from typing import Optional, List, Dict, Any
import jwt 
from jwt.exceptions import InvalidTokenError as JWTError
import hashlib
from fastapi.security import OAuth2PasswordBearer, OAuth2PasswordRequestForm
from fastapi.middleware.cors import CORSMiddleware
import shap

# Add ml directory to path
sys.path.append(os.path.join(os.path.dirname(__file__), '..', 'ml'))
try:
    from data_processor import DataProcessor
    from fairness_auditor import get_fairness_metrics
    from adversarial_tester import AdversarialTester
    from robust_trainer import RobustTrainer
    from watermarker import Watermarker
except ImportError:
    # Fallback for structural changes
    print("Warning: ML modules not found in path. Ensure CWD is correct.")

# --- Security Configuration ---
SECRET_KEY = "SUPER_SECRET_KEY_FOR_PROTOTYPE" 
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 30

# OAuth2 scheme point to our token endpoint
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/api/token")

def get_password_hash(password):
    return hashlib.sha256(password.encode()).hexdigest()

def verify_password(plain_password, hashed_password):
    return get_password_hash(plain_password) == hashed_password

# Role Definitions
ROLES = {
    "SECURITY_ADMIN": ["predict", "audit", "harden", "monitor"],
    "MORTGAGE_OFFICER": ["predict", "monitor"],
    "AUDITOR": ["monitor"]
}

# Mock User Database with Roles
FAKE_USERS_DB = {
    "admin": {
        "username": "admin",
        "hashed_password": get_password_hash("decision_dna_2024"),
        "role": "SECURITY_ADMIN",
        "disabled": False,
    },
    "officer": {
        "username": "officer",
        "hashed_password": get_password_hash("officer_pass_2024"),
        "role": "MORTGAGE_OFFICER",
        "disabled": False,
    },
    "auditor": {
        "username": "auditor",
        "hashed_password": get_password_hash("auditor_pass_2024"),
        "role": "AUDITOR",
        "disabled": False,
    }
}

app = FastAPI(title="Decision DNA Consolidated API", version="3.0.0")

# CORS middleware for development flexibility
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# --- Application State ---
MODELS_DIR = "models"
MODEL_PATH = os.path.join(MODELS_DIR, "random_forest_model_prod.pkl")
MONITOR_MODEL_PATH = os.path.join(MODELS_DIR, "logistic_model_prod.pkl")
SCALER_PATH = os.path.join(MODELS_DIR, "scaler_prod.pkl")
METRICS_PATH = os.path.join(MODELS_DIR, "model_metrics_prod.json")

prediction_logs = []
baseline_stats = None
models = {}
processor = None
explainer = None 

# --- Monitoring & Security State (Ported from Node) ---
monitoring_state = {
    "psi": 0.042,
    "klDivergence": 0.015,
    "status": "Stable"
}

threat_state = {
    "level": "Low",
    "integrity": "Verified"
}

mitigation_state = {
    "active": False,
    "group_thresholds": {
        "standard": 0.5,
        "Female": 0.5,
        "18-25": 0.5
    },
    "last_audit_di": 1.0,
    "mitigation_history": []
}

security_state = {
    "robustness_score": 0.0,
    "last_red_team_audit": None,
    "audit_history": [],
    "is_watermarked": False,
    "watermark_confidence": 0.0
}

@app.on_event("startup")
def startup_event():
    global models, processor, baseline_stats, explainer
    try:
        print("Startup: Loading production models...")
        if not os.path.exists(MODELS_DIR):
            os.makedirs(MODELS_DIR, exist_ok=True)
            
        if os.path.exists(MODEL_PATH):
            models['production'] = joblib.load(MODEL_PATH)
        if os.path.exists(MONITOR_MODEL_PATH):
            models['monitoring'] = joblib.load(MONITOR_MODEL_PATH)
            
        if os.path.exists(SCALER_PATH):
            processor = DataProcessor(scaler_path=SCALER_PATH)
            processor.scaler = joblib.load(SCALER_PATH)
        
        if os.path.exists(METRICS_PATH):
            with open(METRICS_PATH, 'r') as f:
                baseline_stats = json.load(f)
        
        if 'production' in models:
            print("Initializing SHAP tree explainer...")
            explainer = shap.TreeExplainer(models['production'])
            
        print("Decision DNA Consolidated API initialized successfully.")
    except Exception as e:
        print(f"Initialization error: {e}")

# --- Security Helpers ---
def create_access_token(data: dict, expires_delta: Optional[timedelta] = None):
    to_encode = data.copy()
    expire = datetime.utcnow() + (expires_delta or timedelta(minutes=60))
    to_encode.update({"exp": expire}) 
    return jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)

async def get_current_user(token: str = Depends(oauth2_scheme)):
    credentials_exception = HTTPException(
        status_code=401, detail="Could not validate credentials", headers={"WWW-Authenticate": "Bearer"}
    )
    try:
        # FastAPI might receive 'Bearer <token>' or just '<token>' depending on client
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        username: str = payload.get("sub")
        if username is None: raise credentials_exception
    except JWTError: raise credentials_exception
    user = FAKE_USERS_DB.get(username)
    if user is None: raise credentials_exception
    return user

def require_permissions(required_action: str):
    async def permission_checker(current_user: dict = Depends(get_current_user)):
        role = current_user.get("role")
        if not role or required_action not in ROLES.get(role, []):
            raise HTTPException(
                status_code=403, 
                detail=f"Permission denied: {required_action} unauthorized for role {role}"
            )
        return current_user
    return permission_checker

# --- API Router with /api prefix for frontend compatibility ---
api_router = APIRouter(prefix="/api")

# --- Schemas ---
class ApplicantDetails(BaseModel):
    id: Optional[str] = "LENDING-NEW"
    name: Optional[str] = "Anonymous"
    nationality: Optional[str] = "Unknown"
    income: float
    debtRatio: float = 0.3
    creditScore: int
    loanAmount: float
    # Defaults to match original server.ts behavior
    monthsEmployed: int = 24
    numCreditLines: int = 5
    totalBalance: float = 5000
    totalCreditLimit: float = 20000
    pastDuePayments: int = 0
    gender: str = "Male"
    age: int = 30

class PredictRequest(BaseModel):
    applicant: ApplicantDetails
    modelId: str

class PredictionResponse(BaseModel):
    riskProbability: float
    decision: str
    confidence: float
    explanations: Optional[dict] = None
    modelId: str
    mitigation_context: Optional[dict] = None

class AttackRequest(BaseModel):
    type: str

class TrainRequest(BaseModel):
    architecture: str
    epochs: int = 10
    learningRate: float = 0.001

@api_router.post("/token")
async def login(form_data: OAuth2PasswordRequestForm = Depends()):
    user = FAKE_USERS_DB.get(form_data.username)
    if not user or not verify_password(form_data.password, user["hashed_password"]):
        raise HTTPException(status_code=400, detail="Incorrect username or password")
    
    access_token = create_access_token(data={"sub": user["username"]})
    return {"access_token": access_token, "token_type": "bearer"}

@api_router.get("/health")
def health():
    return {"status": "ok", "timestamp": int(datetime.utcnow().timestamp() * 1000)}

@api_router.get("/model-metrics")
def get_model_metrics():
    if os.path.exists(METRICS_PATH):
        with open(METRICS_PATH, 'r') as f:
            return json.load(f)
    return {
        "logistic_regression_accuracy": 0.9252,
        "random_forest_accuracy": 0.9418,
        "timestamp": datetime.now().isoformat()
    }

@api_router.get("/model-metadata")
def get_model_metadata():
    return {
        "version": "1.1.0",
        "production_model": "random_forest",
        "trained_at": datetime.now().isoformat()
    }

@api_router.get("/models")
def get_models():
    return {
        "status": "success",
        "data": [
            { "id": 'm1', "type": 'Logistic Regression', "version": '1.0.0', "status": 'Stable Baseline', "role": 'Monitoring' },
            { "id": 'm2', "type": 'Random Forest', "version": '1.1.0', "status": 'Active', "role": 'Production' }
        ]
    }

@api_router.post("/predict", response_model=PredictionResponse)
async def predict_risk(req: PredictRequest, _ = Depends(require_permissions("predict"))):
    if 'production' not in models:
        raise HTTPException(status_code=503, detail="Models not loaded")
    
    try:
        input_dict = req.applicant.dict()
        # Features used by DataProcessor
        proc_dict = {
            "income": input_dict["income"],
            "loanAmount": input_dict["loanAmount"],
            "creditScore": input_dict["creditScore"],
            "monthsEmployed": input_dict.get("monthsEmployed", 24),
            "numCreditLines": input_dict.get("numCreditLines", 5),
            "totalBalance": input_dict.get("totalBalance", 5000),
            "totalCreditLimit": input_dict.get("totalCreditLimit", 20000),
            "pastDuePayments": input_dict.get("pastDuePayments", 0)
        }
        input_df = pd.DataFrame([proc_dict])
        
        if processor is None:
            raise Exception("Data processor not initialized")
            
        X_scaled = processor.transform(input_df)
        
        # Prediction
        prob = models['production'].predict_proba(X_scaled)[0][1]
        
        # Demographic check for mitigation logic
        group = input_dict.get('gender', 'Male')
        threshold = mitigation_state["group_thresholds"].get("standard", 0.5)
        if mitigation_state["active"] and group == "Female":
            threshold = mitigation_state["group_thresholds"]["Female"]
            
        risk_score = float(prob)
        # Decision logic: probability of risk >= threshold means Reject
        # Decision logic: probability of success >= threshold means Approve
        # In current context, risk_score is probability of class 1 (Reject)
        decision = "REJECT" if risk_score >= threshold else "APPROVE"
        
        # SHAP
        explanations = {}
        if explainer:
            try:
                shap_values = explainer.shap_values(X_scaled)
                contributions = shap_values[1][0] if isinstance(shap_values, list) else shap_values[0]
                for i, feat in enumerate(processor.feature_cols):
                    if i < len(contributions):
                        explanations[feat] = round(float(contributions[i]), 4)
            except Exception as e:
                print(f"SHAP Error: {e}")

        # Log for distribution monitoring
        log_entry = input_dict.copy()
        log_entry['risk_score'] = risk_score
        log_entry['decision'] = decision
        log_entry['timestamp'] = datetime.now().isoformat()
        prediction_logs.append(log_entry)
        
        # Calculate confidence
        confidence = risk_score if decision == "REJECT" else (1 - risk_score)
        
        # Write to dataset.csv
        try:
            dataset_path = os.path.join(os.path.dirname(__file__), '..', 'dataset.csv')
            if os.path.exists(dataset_path):
                # Format: id,name,nationality,income,debtRatio,creditScore,loanAmount,riskProbability,decision
                with open(dataset_path, "a", encoding="utf-8") as f:
                    app_id = input_dict.get("id", f"LENDING-{int(datetime.now().timestamp())}")
                    name = input_dict.get("name", "Anonymous")
                    # Quote the name to match CSV format: "John Doe"
                    name_quoted = f'"{name}"' if not name.startswith('"') else name
                    nationality = input_dict.get("nationality", "Unknown")
                    income = input_dict.get("income", 0)
                    debt_ratio = f"{input_dict.get('debtRatio', 0):.4f}"
                    credit_score = input_dict.get("creditScore", 0)
                    loan_amount = input_dict.get("loanAmount", 0)
                    risk_prob = f"{risk_score:.4f}"
                    # Decision needs to be title case "Approve" or "Reject"
                    fmt_decision = decision.capitalize()
                    
                    csv_row = f"{app_id},{name_quoted},{nationality},{income},{debt_ratio},{credit_score},{loan_amount},{risk_prob},{fmt_decision}\n"
                    f.write(csv_row)
        except Exception as e:
            print(f"Failed to write to dataset.csv: {e}")
        
        return PredictionResponse(
            riskProbability=round(float(risk_score), 4), 
            decision=str(decision),
            confidence=round(float(confidence), 4),
            explanations=explanations,
            modelId=req.modelId,
            mitigation_context={
                "active": bool(mitigation_state["active"]),
                "applied_threshold": float(threshold)
            }
        )
    except Exception as e:
        import traceback
        traceback.print_exc()
        raise HTTPException(status_code=500, detail=str(e))

@api_router.get("/monitoring-drift")
async def get_drift(_ = Depends(require_permissions("monitor"))):
    global monitoring_state
    if len(prediction_logs) < 5: 
        return {**monitoring_state, "timestamp": int(datetime.utcnow().timestamp() * 1000)}
    
    df = pd.DataFrame(prediction_logs)
    # PSI Calculation
    actual_dist = df['decision'].value_counts(normalize=True).get('REJECT', 0)
    expected_reject_rate = 0.35 
    epsilon = 1e-6
    psi = (actual_dist - expected_reject_rate) * np.log((actual_dist + epsilon) / (expected_reject_rate + epsilon))
    
    monitoring_state["psi"] = round(float(psi), 4)
    if psi > 0.1: monitoring_state["status"] = "Drift Detected"
    else: monitoring_state["status"] = "Stable"
        
    return {**monitoring_state, "timestamp": int(datetime.utcnow().timestamp() * 1000)}

@api_router.post("/security-attack")
async def trigger_attack(req: AttackRequest, _ = Depends(require_permissions("audit"))):
    global monitoring_state, threat_state
    
    attack_type = req.type
    if attack_type == 'INCOME_INFLATION':
        monitoring_state["psi"] = 0.285
        monitoring_state["status"] = 'Critical Drift'
        threat_state["level"] = 'Critical'
        threat_state["integrity"] = 'Compromised'
    elif attack_type == 'DATA_POISONING':
        monitoring_state["psi"] = 0.154
        monitoring_state["status"] = 'Warning'
        threat_state["level"] = 'Medium'
    else:
        monitoring_state["psi"] = 0.08
        threat_state["level"] = 'Low'

    return {
        "status": "alert",
        "message": f"Simulated {attack_type} attack detected and mitigated.",
        "timestamp": int(datetime.utcnow().timestamp() * 1000),
        "newPsi": monitoring_state["psi"]
    }

@api_router.post("/reboot")
async def reboot(_ = Depends(require_permissions("audit"))):
    global monitoring_state, threat_state, prediction_logs
    monitoring_state = {"psi": 0.042, "klDivergence": 0.015, "status": "Stable"}
    threat_state = {"level": "Low", "integrity": "Verified"}
    prediction_logs = []
    # Could also reload models here if needed
    return {"status": "success", "message": "System rebooted. Baseline restored."}

@api_router.post("/train-model")
async def train_model(req: TrainRequest, background_tasks: BackgroundTasks, _ = Depends(require_permissions("harden"))):
    def run_retrain():
        import subprocess
        print("Retraining models via background task...")
        subprocess.run([sys.executable, "ml/retraining_pipeline.py"])
        startup_event()
        print("Models reloaded after retraining.")

    background_tasks.add_task(run_retrain)
    
    return {
        "status": "success",
        "message": "Models training started in background",
        "featureImportance": [
            {"feature": "Credit Score", "weight": 0.45},
            {"feature": "Income", "weight": 0.35},
            {"feature": "Debt Ratio", "weight": 0.20}
        ],
        "metrics": {
            "logistic": {"accuracy": 0.91, "precision": 0.89, "recall": 0.88, "f1": 0.885},
            "rf": {"accuracy": 0.94, "precision": 0.93, "recall": 0.92, "f1": 0.925}
        }
    }

# --- Include API Router ---
app.include_router(api_router)

# --- Serve Static Files ---
if os.path.exists("frontend/dist"):
    app.mount("/", StaticFiles(directory="frontend/dist", html=True), name="static")

if __name__ == "__main__":
    import uvicorn
    # When running as a script, we typically use the app object directly or the module path
    # If running from inside 'app' folder: uvicorn main:app
    # If running from repo root: uvicorn app.main:app
    print(f"Starting consolidated FastAPI server on port 8007...")
    uvicorn.run(app, host="0.0.0.0", port=8007)
